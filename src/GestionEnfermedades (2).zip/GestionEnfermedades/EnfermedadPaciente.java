package GestionEnfermedades;

public record EnfermedadPaciente(String enfermedades, String alergias, String medicacion) {
}
